# In-game multiplayer checklist — NOT YET RUN

Record date, client build (`/dump GetBuildInfo()`), zone/instance, quest/NPC IDs, addon versions, party composition, and observed result for each case. Use expendable attempts where starting early could inconvenience participants. Enable Lua errors with `/console scriptErrors 1`. Simulations do not establish visual layout, live API access, script timing, or chat delivery.

## Before starting

- [ ] Install the ZIP on 2–5 clients; confirm title and TOC load without errors on Forever 1.60.1/16001 or document the actual build.
- [ ] Disable automatic quest acceptance, reward completion, and gossip selection. Verify normal game controls still work; no protected-action/taint errors in or out of combat.
- [ ] Check window placement, dragging, clipping, long realm names, 5 rows, low/high UI scale, close/reopen, and custom quest UI compatibility. Confirm statuses and leader provenance are legible.
- [ ] Observe PARTY chat and addon-message delivery both outdoors and in Maraudon/BRD, including chat lockdown. Record missing/restricted APIs rather than marking the test passed.

## Quest/action checks

- [ ] **Celebras #7046 / NPC #13716:** keep one player's #7044 objectives complete but unturned-in. Opening #7046 must warn before Accept and show that person Not Ready. Hand in #7044 on everyone; readiness should update automatically without everyone accepting #7046 first or keeping the offer open. One player accepts only after readiness. Record whether actual `QUEST_ACCEPT_CONFIRM` offers reach others, who accepts, and actual ritual credit. Check the ritual/book stage separately; the addon does not operate it.
- [ ] **OOX:** independently test #648 after #351, #836 after #485, and #2767 after #2766. The beacon hand-in is not itself the rescue trigger. Check missing prerequisite, completed-but-held prerequisite, handed-in prerequisite, full log, and a refused/missed group invitation. Record each robot's actual departure and retry behavior.
- [ ] **Defias #155 after #142; Remtravel #731 after #729:** verify correct identically named chain step, start timing, group offers, and prerequisite transitions.
- [ ] **Therylune #945, Kerlonian #5321, Ruul #6482:** check faction/minimum level, no invented prerequisite, first-accept timing, and invitation behavior. For Kerlonian verify the current route/bag interaction and whether the historical Horn of Awakening mechanic still applies; current Forever corrections differ from the inherited objective. Ready does not certify later escort success.
- [ ] **Gyromast #2078:** open robot #6669's gossip. Warning must precede choosing the key option. A member missing #2078 is blocked; an active quest still leaves key/robot details Unknown for leader assessment. Confirm key availability, the follow sequence and hostility near Gelkak. Observe that any gossip selection conservatively retires preparation without replacing the button.
- [ ] **Love Potion #4201 / Nagmara #9500:** open both progress and reward screens. Warning must precede handing in and explicitly say reported behavior. Verify departure timing and who actually needs a hand-in; witnesses must not be forced to hold this quest. Separately investigate repeat-use gossip after prior completion; it is outside this release.

## Party and failure checks

- [ ] Run 2-, 3-, 4-, and 5-player all-addon parties. Let a nonleader detect the event. All windows open, all members appear, one initial message comes from the actual leader, and one specific next-action message appears automatically with the UI proceed notice.
- [ ] Disable the addon on one member: Waiting becomes Unknown; the leader confirms only that missing information. Automatic evidence and leader confirmation remain visually distinct.
- [ ] Disable it on the leader: the alphabetically first responding full name sends the warning under its own name. Use the token-bound PARTY command to confirm the leader/other nonresponders; test Ready and Not ready, stale token rejection, and `/p ZKIR status`.
- [ ] Try confirming a disconnected or automatically blocked member; it must fail. A responding client whose facts stop arriving must not be manually bypassed.
- [ ] Change an unrelated quest: manual confirmations remain. Change relevant quest facts, disconnect/reconnect, join/leave, or promote a new leader: old confirmations disappear and only the current leader has controls.
- [ ] Open the same interaction simultaneously. Repeat opening it, close/reopen the window, reload the leader, reload other clients, and reload everyone. Check announcement counts and stale approval rejection.
- [ ] Start a legitimate new attempt with `/zkir retry`; every old confirmation/token becomes invalid. Confirm NPC state separately: this command cannot reset the encounter.
- [ ] Restrict/unregister messaging or interrupt connectivity. Expect suspended/Unknown readiness without Lua errors, retries flooding chat, or a false proceed notice. Restore communication, coordinate a new attempt, and retry. Document silent initial partitions as a delivery limitation.
- [ ] Run solo: the pre-action warning appears, no PARTY traffic occurs, and normal game controls remain usable.

For every actual acceptance, record invitation received, accepted, quest present in log, and eventual credit as separate observations. A green row is not evidence that any of those later events happened.
