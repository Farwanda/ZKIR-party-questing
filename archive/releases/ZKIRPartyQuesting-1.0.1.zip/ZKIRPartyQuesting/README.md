# ZKIR PARTY QUESTING

A small advisory addon for **WoW Forever 1.60.1, interface 16001**. It warns before twelve researched quest/NPC interactions, opens one party window automatically, exchanges preparation facts, and sends the warning and next-action message automatically. Normal quest, reward, and dialogue controls remain available.

**Install:** extract [ZKIRPartyQuesting-1.0.1.zip](https://github.com/Farwanda/ZKIR-party-questing/raw/refs/heads/main/dist/ZKIRPartyQuesting-1.0.1.zip) into your Forever client's `Interface/AddOns` directory. The resulting path must be `Interface/AddOns/ZKIRPartyQuesting/ZKIRPartyQuesting.toc`. Enable **ZKIR PARTY QUESTING**, then restart the client if installing while it is open. No libraries or other addons are required.

**Updating from 1.0.0:** replace the existing `ZKIRPartyQuesting` folder, then restart WoW or `/reload`. Every addon user in the party should update: 1.0.0 does not recognize the newly added A-Me 01 escort. Version 1.0.1 warns when opening escort quest #4245, before Accept; the identically named find/repair steps #4243/#4244 do not trigger that warning.

Disable other addons' automatic quest acceptance, turn-in, and dialogue selection for these interactions. A warning cannot stop another addon from acting during the same game event.

## Normal use

Open a supported quest or NPC conversation and **wait**. Every responding addon opens the window. All current party members appear, including nonresponders. Discovery takes about five seconds, followed by announcement acknowledgement; the local warning appears immediately.

Hover a row for its specific blocker or missing evidence.

- **Ready — automatic:** the researched quest preparation was checked. Acceptance readiness requires prerequisite hand-ins, an absent/unrewarded target, required level/faction, and log space. Nobody must accept an escort before its first acceptance. This does not check range, layers, NPC availability, combat preparation, or guarantee an invitation or credit.
- **Not Ready — automatic:** a known blocker or disconnection. Complete objectives on a prerequisite do **not** count as handing it in.
- **Waiting:** an addon response is still expected.
- **Unknown:** no response or insufficient evidence. The actual leader can use the row's Ready/Not ready controls. Confirmations are explicitly labelled **leader confirmed**. Stale addon facts and verified blockers cannot be overridden.

The leader's addon announces; otherwise the alphabetically first responding full player name announces under **its own name**. A leader without the addon can use `/p ZKIR TOKEN ready Name-Realm` or `notready` to resolve missing information. The initial fallback warning includes the token. `/p ZKIR status` requests current instructions; only the actual leader's commands count. Short names work only when unambiguous.

When everyone is ready, the UI says **You may proceed** and the elected sender announces the specific next action once. There is no announcement or proceed button. Solo play shows local warnings without PARTY traffic.

`/zkir` reopens the window. `/zkir retry` starts a **new attempt**, clearing confirmations; use it after coordinating a real retry or restoring failed communication. It cannot reset an NPC. `/zkir status` displays local status. No automatic quest sharing or acceptance is performed.

## Coverage and verification

Acceptance: Defias #155; OOX #648/#836/#2767; Remtravel #731; Therylune #945; A-Me 01 #4245 after the repair hand-in #4244; Kerlonian #5321; Ruul #6482; Celebras #7046. Dialogue: Gyromast #2078 at robot #6669. Turn-in: Love Potion #4201. The last two require leader assessment of missing event details. The Love Potion warning explicitly labels its historical evidence as reported behavior.

**Simulated verification only:** 25 protocol scenario groups, 9 mocked API/UI groups, and 20 preparation cases passed using Lua 5.1. No live client was available to the developer. A user reported the missing A-Me warning in 1.0.0; the 1.0.1 fix still needs in-game verification. See [multiplayer field checks](docs/MULTIPLAYER_CHECKLIST.md), [protocol limits](docs/PROTOCOL.md), and the [post-implementation quest audit](research/IMPLEMENTATION_REVIEW.md). The older research files are an archive, not this release's supported catalogue.

Run tests with Lua 5.1 via `python3 -m pip install lupa==2.8`, then `python3 tests/run.py`. Build the deterministic install ZIP with `python3 tools/build.py`.
