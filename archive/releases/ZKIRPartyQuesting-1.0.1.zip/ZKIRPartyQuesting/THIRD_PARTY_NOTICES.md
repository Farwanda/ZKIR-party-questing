# Research attribution

The addon contains independently written code and warning text, plus a small curated set of factual quest/NPC identifiers and prerequisite metadata. No upstream addon implementation, database dump, game artwork, or proprietary route data is bundled.

Research references include [Questie](https://github.com/Questie/Questie), [QuestieDB](https://github.com/Questie/QuestieDB), the [Forever UI source mirror](https://github.com/Gethe/wow-ui-source/tree/forever), the Itinerary author's public changelog, Blizzard hotfix notes, and attributed quest-specific player reports. Their licenses and ownership remain their own. See [the implementation audit](research/IMPLEMENTATION_REVIEW.md) for the exact source boundaries.

The optional test dependency Lupa is not distributed in the install ZIP. World of Warcraft and its names belong to Blizzard Entertainment. This addon is unaffiliated with Blizzard.
