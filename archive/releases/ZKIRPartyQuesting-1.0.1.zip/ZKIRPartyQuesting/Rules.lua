local _, NS = ...

-- Curated factual IDs. See research/IMPLEMENTATION_REVIEW.md for evidence and limits.
-- PARTY_ACCEPT metadata supports an offer; it does not guarantee delivery or credit.
local rules = {}
local function escort(id, npc, title, previous, level, faction, consequence)
    local key = "a" .. id
    rules[key] = {id = key, questID = id, npcID = npc, title = title, kind = "accept",
        prerequisites = previous and {previous} or {}, minLevel = level, faction = faction,
        automatic = true, partyAccept = true,
        warning = "WAIT for everyone before accepting " .. title .. ". " .. consequence,
        nextAction = "Everyone ready for " .. title .. " — one player may accept; others join when offered."}
end
escort(155, 467, "The Defias Brotherhood", 142, 14, "Alliance", "The Traitor starts moving; finish prerequisite hand-ins first.")
escort(648, 7784, "Rescue OOX-17/TN!", 351, 43, "Both", "The escort starts immediately; hand in Find OOX-17/TN! first.")
escort(731, 2917, "The Absent Minded Prospector", 729, 15, "Alliance", "Remtravel starts his escort; hand in step #729 first.")
escort(836, 7806, "Rescue OOX-09/HL!", 485, 43, "Both", "The escort starts immediately; hand in Find OOX-09/HL! first.")
escort(945, 3584, "Therylune's Escape", nil, 10, "Alliance", "Therylune starts moving; gather everyone first.")
escort(2767, 7807, "Rescue OOX-22/FE!", 2766, 40, "Both", "The escort starts immediately; hand in Find OOX-22/FE! first.")
escort(4245, 9623, "Chasing A-Me 01", 4244, 48, "Both", "A-Me starts her escort; everyone must hand in the Mithril Casing repair step #4244 first.")
escort(5321, 11218, "The Sleeper Has Awakened", nil, 17, "Alliance", "Kerlonian starts moving; gather everyone and check his supplies first.")
escort(6482, 12818, "Freedom to Ruul", nil, 19, "Horde", "Ruul starts his escape; gather everyone first.")
escort(7046, 13716, "The Scepter of Celebras", 7044, 41, "Both", "The long ritual starts; everyone must hand in Legends of Maraudon first.")
rules.g2078 = {id = "g2078", questID = 2078, npcID = 6669, title = "Gyromast's Revenge",
    kind = "gossip", prerequisites = {2098}, automatic = false,
    warning = "WAIT for everyone before the robot's key dialogue. Have Gyromast's Revenge accepted; the robot follows, then turns hostile near Gelkak.",
    nextAction = "Everyone confirmed prepared — one player may use the robot's key dialogue; stay together for the later fight."}
rules.t4201 = {id = "t4201", questID = 4201, npcID = 9500, title = "The Love Potion",
    kind = "turnin", prerequisites = {}, automatic = false,
    warning = "WAIT for everyone before handing in The Love Potion. Reported behavior: Nagmara and Rocknot leave for the door scene; finish coordinating hand-ins first.",
    nextAction = "Everyone confirmed prepared — coordinate the needed hand-ins now, before Nagmara leaves."}
NS.Rules = rules
