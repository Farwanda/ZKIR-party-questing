local _, NS = ...

-- The adapter supplies tri-state facts: nil is unavailable, never false by default.
-- Ready checks preparation for this action, not server range/layer/script state.
function NS.Evaluate(rule, snapshot)
    local parts, blockers, missing = {}, {}, false
    local function value(key, v)
        parts[#parts + 1] = key .. "=" .. tostring(v)
        if v == nil then missing = true end
        return v
    end
    local function block(reason) blockers[#blockers + 1] = reason end
    for _, id in ipairs(rule.prerequisites) do
        local q = snapshot.quests[id] or {}
        local done = value("reward" .. id, q.rewarded)
        if done == false then block("PREREQUISITE_" .. id) end
        if q.active == true and done ~= true then block("HAND_IN_" .. id) end
        -- Objective counts are deliberately absent: they cannot prove a hand-in.
    end
    local target = snapshot.quests[rule.questID] or {}
    local rewarded = value("reward", target.rewarded)
    local active = value("active", target.active)
    local failed = active == true and value("failed", target.failed) or false
    if failed == true then block("FAILED") end
    if rule.kind == "accept" then
        if rewarded == true then block("ALREADY_REWARDED") end
        if active == true then missing = true end -- may be a running attempt; never promise joining it
        local capacity = value("space", snapshot.space)
        if capacity == false then block("LOG_FULL") end
        local level = value("level", snapshot.level and snapshot.level >= rule.minLevel)
        if level == false then block("LEVEL") end
        local faction = value("faction", snapshot.faction)
        if faction and rule.faction ~= "Both" and faction ~= rule.faction then block("FACTION") end
    elseif rule.kind == "gossip" then
        if active == false then block("NEED_QUEST") end
        if value("complete", target.complete) == true then block("ALREADY_COMPLETE") end
        -- Key availability and robot state aren't inferred from a quest-log entry.
        missing = true
    else
        -- Other participants may be witnesses rather than hand-in candidates.
        -- Do not invent a requirement that everyone holds this turn-in quest.
        value("complete", target.complete)
        missing = true
    end
    local state, reason = "R", "PREPARED"
    if #blockers > 0 then state, reason = "N", blockers[1]
    elseif missing or not rule.automatic then state, reason = "U", "VERIFY_DETAILS" end
    if active and rule.kind == "accept" and state == "U" then reason = "ALREADY_ACTIVE" end
    return {state = state, reason = reason, signature = table.concat(parts, ";")}
end
