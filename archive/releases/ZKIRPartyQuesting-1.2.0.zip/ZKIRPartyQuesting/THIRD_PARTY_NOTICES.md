# Research attribution

The addon contains independently written code and warning text, plus a small curated set of factual quest/NPC identifiers and prerequisite metadata. No upstream addon implementation, database dump, game artwork, or proprietary route data is bundled.

Research references include [Questie](https://github.com/Questie/Questie), [QuestieDB](https://github.com/Questie/QuestieDB), the [Forever UI source mirror](https://github.com/Gethe/wow-ui-source/tree/forever), historical [CMaNGOS](https://github.com/cmangos/mangos-classic) and [vMaNGOS](https://github.com/vmangos/core) scripts, the Itinerary author's public changelog, Blizzard hotfix notes, original Method/Wowhead dungeon guides, and attributed quest-specific player reports. Their licenses and ownership remain their own. See the [dungeon audit](research/DUNGEON_AUDIT.md), [escort catalogue](research/ESCORT_COVERAGE.md), and [historical implementation audit](research/IMPLEMENTATION_REVIEW.md) for exact source boundaries. Historical emulator scripts inform research; no implementation was copied from them.

The optional test dependency Lupa is not distributed in the install ZIP. World of Warcraft and its names belong to Blizzard Entertainment. This addon is unaffiliated with Blizzard.
